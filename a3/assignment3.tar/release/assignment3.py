import urllib.request
import base64
import binascii
from pymd5 import md5, padding

from problem1 import ctxts_hex, ctxts_bin
from problem2 import KEY, get_user_url, query_url

################################################################################
# 
# Starter file for UChicago CMSC 23200 Assignment 3, Winter 2024
#
################################################################################


################################################################################
# PROBLEM 1 SOLUTION
################################################################################

# Add your helper code for solving Problem 1 here.

# Submission function for grading
def problem1():
    # Fill in this array with the four decoded plaintexts *in order*
    # no further implementation required in this function
    ptxts = []
    return ptxts 

################################################################################
# PROBLEM 2 SOLUTION
################################################################################

def problem2(cnet):
    url = get_user_url(cnet)
    # Fill in your solution to Problem 2 here
    return ''  # goal: return a new URL causes query_url(...) to return success for an admin login 


################################################################################

# Code below here will be run if you execute 'python4 assignment3.py'.
# This code here won't be graded, and your code above shouldn't depend on it.
if __name__ == "__main__":
    # optional driver code here, e.g., to help test your solution to Problem 2
    exit()
